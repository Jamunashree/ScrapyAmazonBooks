# -*- coding: utf-8 -*-
import scrapy
from ab.items import AbItem


class AmazonbooksSpider(scrapy.Spider):
    name = 'amazonbooks'
    allowed_domains = ['amazon.in']
    start_urls = ['https://www.amazon.in/Harry-Potter-Philosophers-Stone-Rowling/dp/1408855658/ref=lp_14142609031_1_1?s=books&ie=UTF8&qid=1529642038&sr=1-1',
                  'https://www.amazon.in/Grandmas-Bag-Stories-Sudha-Murty/dp/0143333623/ref=lp_14142609031_1_2?s=books&ie=UTF8&qid=1529642038&sr=1-2',
                  'https://www.amazon.in/Matilda-Dahl-Fiction-Roald/dp/0141365463/ref=lp_14142609031_1_3?s=books&ie=UTF8&qid=1529642038&sr=1-3',
                  'https://www.amazon.in/Great-Stories-Children-Ruskin-Bond/dp/8129118920/ref=lp_14142609031_1_4?s=books&ie=UTF8&qid=1529642038&sr=1-4',
                  'https://www.amazon.in/Very-Hungry-Caterpillar-Eric-Carle/dp/0140569324/ref=lp_14142609031_1_5?s=books&ie=UTF8&qid=1529642038&sr=1-5',
                  'https://www.amazon.in/Charlie-Chocolate-Factory-Dahl-Fiction/dp/0141365374/ref=lp_14142609031_1_6?s=books&ie=UTF8&qid=1529646844&sr=1-6',
                  'https://www.amazon.in/How-Taught-My-Grandmother-Read/dp/014333364X/ref=lp_14142609031_1_7?s=books&ie=UTF8&qid=1529646844&sr=1-7',
                  'https://www.amazon.in/Adventures-Tom-Sawyer-Mark-Twain/dp/8175992913/ref=lp_14142609031_1_8?s=books&ie=UTF8&qid=1529646844&sr=1-8',
                  'https://www.amazon.in/Wonder-R-J-Palacio/dp/0552565970/ref=lp_14142609031_1_9?s=books&ie=UTF8&qid=1529646844&sr=1-9',
                  'https://www.amazon.in/Charlottes-Web-Puffin-Book-White/dp/0141354828/ref=lp_14142609031_1_10?s=books&ie=UTF8&qid=1529646844&sr=1-10'
                  ]

    def parse(self, response):
        items = AbItem()
        title = response.xpath('//span[@id="productTitle"]//text()').extract()
        sale_price = response.xpath('//span[@class="a-size-base a-color-price a-color-price"]//text()').extract()
        level = response.xpath('//td[@class="bucket"]/div[@class="content"]/ul/li[1]//text()').extract()#
        author = response.xpath('//span[@class = "a-declarative"]/a[@class="a-link-normal contributorNameID"]/text()').extract()
        items['Title'] = ''.join(title).strip()
        items['SalePrice'] = ''.join(sale_price).strip()
        items['Level'] = ''.join(level).strip()
        items['Author'] = ''.join(author).strip()
        yield items





